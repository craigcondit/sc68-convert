/**
 * @ingroup   emu68_devel
 * @file      table68.c
 * @date      13/03/1999
 * @author    Ben(jamin) Gerard <ben@sashipa.com>
 * @brief     68000 opcode table
 * @version   $Id: table68.c 503 2005-06-24 08:52:56Z loke $
 */

/* Copyright (C) 1998-2001 Ben(jamin) Gerard */

#include "emu68/table.inc"
